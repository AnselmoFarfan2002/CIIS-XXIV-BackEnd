const TypeEvent=require("../models/TypeEvent")
const getTypeEvents=()=>{

}

const getOneTypeEvent=()=>{

}

const createTypeEvent=(dataObject)=>{

}

const updateTypeEvent=(id,dataObject)=>{

}

const deleteTypeEvent=(id)=>{
    
}


module.exports={
    getTypeEvents,
    getOneTypeEvent,
    createTypeEvent,
    updateTypeEvent,
    deleteTypeEvent,
}