const GalleryEvent=require("../models/GalleryEvents");
const getGalleryEvents=(req,res)=>{

}

const getOneGalleryEvent=(req,res)=>{

}

const createGalleryEvent=(req,res)=>{

}

const updateGalleryEvent=(req,res)=>{

}

const deleteGalleryEvent=(req,res)=>{
    
}


module.exports={
    getGalleryEvents,
    getOneGalleryEvent,
    createGalleryEvent,
    updateGalleryEvent,
    deleteGalleryEvent,
}