const {Router}=require("express");
const routerUser=Router();

// routerUser
// .post('/register',userRegisterDTO,createRegister);


module.exports=routerUser;