const { handleHttpError } = require("../middlewares/handleError");
const TypeEventService=require("../services/typeEvent.service");

const getTypeEvents=(req,res)=>{

}

const getOneTypeEvent=(req,res)=>{

}

const createTypeEvent=(req,res)=>{

}

const updateTypeEvent=(req,res)=>{

}

const deleteTypeEvent=(req,res)=>{
    
}



module.exports={
    getTypeEvents,
    getOneTypeEvent,
    createTypeEvent,
    updateTypeEvent,
    deleteTypeEvent,
}